package com.forum.web.page;

public interface Page {
    void verify(Browser browser);
}
